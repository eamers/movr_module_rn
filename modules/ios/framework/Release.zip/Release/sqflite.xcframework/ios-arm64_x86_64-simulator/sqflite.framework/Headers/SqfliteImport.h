//
//  SqfliteImport.h
//  sqflite
//
//  Created by Alexandre Roux on 24/10/2022.
//
#ifndef SqfliteImport_h
#define SqfliteImport_h

#if TARGET_OS_IPHONE
#import <Flutter/Flutter.h>
#else
#import <FlutterMacOS/FlutterMacOS.h>
#endif

#endif // SqfliteImport_h
